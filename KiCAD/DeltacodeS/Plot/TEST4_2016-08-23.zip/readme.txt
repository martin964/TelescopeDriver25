Layer List:
-----------
TEST4-Edge.Cuts.gbr	PCB Edge 160x100mm			Platinenumriss 160x100mm
TEST4-F.Cu.gbr		Top Copper				Kupferlage OPEN
TEST4-In1.Cu.gbr	Inner (top) Layer, GND			Obere Innenlage, GND
TEST4-In2.Cu.gbr	Inner (bottom) Layer, VCC		Untere Innenlage, VCC
TEST4-B.Cu.gbr		Bottom Copper Layer			Kupferlage UNTEN
TEST4-F.Mask.gbr	Top Solder Mask				L�tstopplack OBEN		
TEST4-B.Mask.gbr	Bottom Solder Mask			L�tstopplack UNTEN
TEST4-F.Paste.gbr	Top Solder Paste Mask (Stencil)		Pastenschablone OBEN			
TEST4-NPTH.drl		Drill file, Mechanical Holes		Bohrungen ohne Kupfer
TEST4.drl		Drill file, Vias and Copper Holes	Elektrisch leitende Bohrungen und Vias

Wenn etwas unklar ist, bitte ich um R�ckmeldung:
For Questions, please contact me:

E-Mail: martin.cibulski@gmx.de
Phone : +49 151 5711 0249

